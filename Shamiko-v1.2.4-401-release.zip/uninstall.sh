rm -rf /data/adb/shamiko
rm -rf /data/adb/post-fs-data.d/.shamiko_cleanup.sh
