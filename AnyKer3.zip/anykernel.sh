block=boot
is_slot_device=auto
ramdisk_compression=auto
patch_vbmeta_flag=auto
no_magisk_check=1
. tools/ak3-core.sh
split_boot
flash_boot